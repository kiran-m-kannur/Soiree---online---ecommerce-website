# SOIREE-FASHION_ECOMMERCE

Since the node_modules folder is very large and takes up a lot of time to extract, they have not been included in the folder.


STEPS TO FOLLOW:

1.After downloading the SOIRRE-FASHION_ECOMMERCE folder make sure to move the public folder into the frontend folder.


2.SOIREE> npm install

  SOIREE> npm install express
  
  SOIREE> npm install express-async-handler
  
  SOIREE> npm install mongoose
  
  SOIREE> npm install bcryptjs
  
  SOIREE> npm install jsonwebtoken
  
  SOIREE> npm install dotenv
  
  SOIREE> npm install multer
  
  SOIREE> npm install mongoose
  
  SOIREE> npm start
  


3.IN CASE OF SERVER ERROR

  Go to server.js file in the backend folder and change the port



4.cd frontend
  
  SOIREE\frontend>npm install
  


5.IN CASE IT SHOWS MODULE NOT FOUND ERRORS
  
  SOIREE\frontend>npm install axios
  
  SOIREE\frontend>npm install react-dom
  
  SOIREE\frontend>npm install redux-thunk
  
  SOIREE\frontend>npm install redux
  
  SOIREE\frontend>npm install react-router-dom
  
  SOIREE\frontend>npm install react-scripts
  
  SOIREE\frontend>npm install react
  
  SOIREE\frontend>npm start
  

  
  
 
  
  
  
  
  
	

  
